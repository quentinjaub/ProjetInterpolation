function [indocc] = ComputeFrontierPoints(TrianglesAbsc)

indocc=1;

occ=sum(TrianglesAbsc==TrianglesAbsc(1));
for i = 2:length(TrianglesAbsc)

       occb=sum(TrianglesAbsc==TrianglesAbsc(i));
       if(occb<occ)
           indocc=i;
           occ=occb;
       end

end

