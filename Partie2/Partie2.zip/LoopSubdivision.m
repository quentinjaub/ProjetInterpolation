%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fonction LoopSubdivision
% Permet d'effectuer la subdivision de Loop sur un ensemble de surfaces
% triangulaires
% Parametres : 
%               _coordinates : matrice a trois colonnes. Chaque ligne contient les 
%               coordonnes 3D d'un des points de la discretisation. Ces sommets seront 
%               identifies a l'indice de la ligne correspondante dans la matrice
%               coordinates.
%               _elements3 : matrice a trois colonnes. Chaque ligne contient les indices 
%               des sommets d'un element triangle, dans le sens antihoraire. 
%               _frontierIndex : Liste des indices des points sur la
%               frontiere ( Ordonnés selon le sens trigonometrique )
%               _ nb_iteration : Nombre d'iteration à realiser
% Sorties:
%               _coordinateUpdate :  Nouvelles coordonnées
%               _elementes3Update :  Nouvelle matrice d'indice
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [ coordinateUpdate, elementes3Update ] = LoopSubdivision( coordinate, elements3, frontierIndex, nb_iteration )

    for i = 1:nb_iteration
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%% Calcul des ODD et EVEN POINTS %%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        
        % On parcourt chaque triangle
        % A chaque triangle, on cree 3 nouveaux points sur les arêtes de ce
        % dernier
        
        % Nombre de triangles ( Penser a la maj de nt à chaque iteration )
        nt = size(elements3,1);
        oddVertices = zeros(nt*3,3);
        MajIndexFrontierOdd=zeros(1:length(frontierIndex)); %% Nouveaux Points sur la frontiere
        im=1;
        for k = 1:nt
            % Calcul des odd vertices pour le triangle k
           [newVerticesTriangleK,newIndexFrontierPoint,] = ComputeOddVertex(coordinate,elements3,k);
           oddVertices((k-1)*3+1:k*3,:) = newVerticesTriangleK; % newVerticesTriangleK contient des doublons
           
           while (MajIndexFrontierOdd(im)~=0)
               im=im+1;
           end
           MajIndexFrontierOdd(im:im+length(newIndexFrontierPoint)-1) = newIndexFrontierPoint;
        end    
        % Numerotation nouveaux sommets : 
        IndexOdd = zeros(size(oddVertices,1),1);
        for j =1:size(oddVertices,1)
            if(j==1)
                IndexOdd(1) = 1;
            else
                if (ismember(coordinate(IndexOdd(1:j-1),:),coordinate(IndexOdd(j),:)))
                    
                end
        end
        % Maj elements3
        for j = 1:nt
           elements3Update(j,:) = 
        end
        
        EvenVertices = zeros(size(coordinate,1),3);
        for k = 1:size(coordinate,1)
            %%% Calcul des even vertices
            % On parcourt chaque sommet (xj,yj,zj)
            [veven,MajEvenFrontierIndex] = ComputeEvenVertex(coordinate,elements3,k,frontierIndex);
            EvenVertices(k,:) = veven;
            if (MajEvenFrontierIndex ~=0)
                MajIndexFrontierEven(k)=MajEvenFrontierIndex;
            end
        end
        MajIndexFrontierEven = MajIndexFrontierEven(find(MajIndexFrontierEven~=0));    % On enleve les zeros de MajIndexFrontierEven      
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%% RECONSRTUCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        coordinateUpdate = [oddVertices;EvenVertices];
        elementes3Update=0;
    end

end

