function [veven,MajEvenFrontierIndex] = ComputeEvenVertex(coordinate,elements3,k,frontierIndex)

coorPj=coordinate(k,:);
MajEvenFrontierIndex=[];
 % Point est il interieur ou sur la frontiere ???
 IsFrontier=0;
 for kf=1:length(frontierIndex)
     if(k==frontierIndex(kf))
         % Si le sommet d'indice k se trouve dans frontierIndex
         IsFrontier=1;
     end
 end
 if (IsFrontier==0)
     %Point Interieur
     [indexrows,~] = find(elements3==k);  %-> indices des triangles contenant (xj,yj,zj)
     % On a les indices des triangles contenant Pj
     % -> Calcul des coordonnées des sommets inclus dans les triangles
     % contenant Pj
     [TrianglesCoorUse] = coordinate(elements3(indexrows,:),:);
%      [~,index] = unique(TrianglesCoorUse,'first');        %# Remove duplicates from TrianglesCoorUse
%      TrianglesCoorUse=TrianglesCoorUse(sort(index),:) ;
     
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     % Calcul de l'even Point
     n=size(TrianglesCoorUse,1)-1;
     beta = (1/n)*((5/8)-((3/8)+0.25*cos(2*pi/n))^2);
     veven=[coorPj(1),coorPj(2),coorPj(3)]*(1-n*beta);
     for jeven=1:size(TrianglesCoorUse,1)
         if([coorPj(1),coorPj(2),coorPj(3)]~=TrianglesCoorUse(jeven,:))
             veven = veven + TrianglesCoorUse(jc,:)*beta;
         end
     end
     
 else
     %Point sur la frontiere
     [indexrows,~] = find(elements3==k);  %-> indices des triangles contenant (xj,yj,zj)
     % On a les indices des triangles contenant Pj
     % -> Calcul des coordonnées des sommets inclus dans les triangles
     % contenant Pj
     [TrianglesCoorUse] = coordinate(elements3(indexrows,:),:);
     % On cherche les elements sur le bord 
     [indP1] = ComputeFrontierPoints(TrianglesCoorUse(:,1));
     TrianglesCoorUseb = [TrianglesCoorUse(1:indP1-1,:);TrianglesCoorUse(indP1+1:end,:)];
     [indP2] = ComputeFrontierPoints(TrianglesCoorUseb(:,1));
     veven = (3/4)*[coorPj(1),coorPj(2),coorPj(3)] + (1/8)*(TrianglesCoorUse(indP1,:) + TrianglesCoorUseb(indP2,:));
     MajEvenFrontierIndex = k;
 end


end

